from src.learning.default_argparser import get_argparser

def get_experiment_argparser():
    parser = get_argparser()

    parser.add_argument("--save_dir_base", type=str, default="data/local/experiment/2d_navigation/ellipsoid_task_geometry"
                        , help="Path to saving directory for all data.")
    parser.add_argument("--_rho", type=float, default=0.7, help="Task distribution ellipsoid stretch in the x-direction.")
    parser.add_argument("--_lambda", type=float, default=0.9, help="Task distribution ellipsoid stretch in the y-direction.")
    parser.add_argument("--wandb_project_name", type=str, default="two_d_navigation_task_geo_ellipsoid", help="Project name for wandb.")


    return parser