# Compares different kernel estimation methods on the two-dimensional navigation task with a circular geometry.
# Methods:
# 1. Oracle frames.
# 2. Neural kernel with uniform replay sampling.
# 3. Neural kernel with uniform manifold sampling and different temperature values.

echo "------------------------------------------------------------"
echo "Symmetry discovery using oracle frame and global sampling."
echo "------------------------------------------------------------"

python3 -m examples.two_d_navigation_task_geo_circle.train \
            --use_oracle_frames "true" \
            --sample_data_how "globally" \
            --n_steps_lgs 250000

echo "------------------------------------------------------------"
echo "Symmetry discovery using oracle frame and uniform replay."
echo "------------------------------------------------------------"

python3 -m examples.two_d_navigation_task_geo_circle.train \
            --use_oracle_frames "true" \
            --sample_data_how "uniform_replay" \
            --n_steps_lgs 250000
echo "------------------------------------------------------------"
echo "Symmetry discovery using oracle frame and uniform manifold."
echo "------------------------------------------------------------"

python3 -m examples.two_d_navigation_task_geo_circle.train \
            --use_oracle_frames "true" \
            --sample_data_how "uniform_manifold" \
            --temperature 15 \
            --n_steps_lgs 250000

echo "------------------------------------------------------------"
echo "Symmetry discovery using neural frame and uniform replay sampling."
echo "------------------------------------------------------------"

python3 -m examples.two_d_navigation_task_geo_circle.train \
            --use_oracle_frames "false" \
            --compute_kernel "true" \
            --sample_data_how "uniform_replay" \
            --n_steps_lgs 250000

echo "------------------------------------------------------------"
echo "Symmetry discovery using uniform sampling trained neural frame and uniform manifold symmetry discovery."
echo "------------------------------------------------------------"

python3 -m examples.two_d_navigation_task_geo_circle.train \
            --use_oracle_frames "false" \
            --compute_kernel "false" \
            --sample_data_how "uniform_manifold" \
            --temperature 15 \
            --n_steps_lgs 250000

echo "------------------------------------------------------------"
echo "Training kernel and geometry with uniform manifold sampling and temperature equal 15."
echo "------------------------------------------------------------"

python3 -m examples.two_d_navigation_task_geo_circle.train \
            --use_oracle_frames "false" \
            --compute_kernel "true" \
            --sample_data_how "uniform_manifold" \
            --temperature 15 \
            --n_steps_lgs 250000

echo "------------------------------------------------------------"
echo "Training kernel and geometry with uniform manifold sampling and temperature equal 50."
echo "------------------------------------------------------------"

python3 -m examples.two_d_navigation_task_geo_circle.train \
            --use_oracle_frames "false" \
            --compute_kernel "true" \
            --sample_data_how "uniform_manifold" \
            --temperature 50 \
            --n_steps_lgs 250000

echo "------------------------------------------------------------"
echo "Training kernel and geometry with uniform manifold sampling and temperature equal 100."
echo "------------------------------------------------------------"

python3 -m examples.two_d_navigation_task_geo_circle.train \
            --use_oracle_frames "false" \
            --compute_kernel "true" \
            --sample_data_how "uniform_manifold" \
            --temperature 100 \
            --n_steps_lgs 250000