import torch as th
    
class DenseNN(th.nn.Module):
    """A fully connected neural network with arbitrary layer sizes and ReLU activations."""
    def __init__(self, layer_sizes: list[int]):
        """
        Args:
            layer_sizes (list of int): List of layer sizes, including input and output dimensions.
                                       Example: [2, 64, 128, 2]
        """
        super().__init__()
        layers = []
        for in_dim, out_dim in zip(layer_sizes[:-1], layer_sizes[1:]):
            layers.append(th.nn.Linear(in_dim, out_dim))
            layers.append(th.nn.ReLU()) 
        layers.pop()
        self.net = th.nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)
    

class FrameNet(th.nn.Module):
    def __init__(self, ambient_dim: int, kernel_dim: int, hidden_layer_dims: list[int]):
        """Dense neural network to approximate a basis of shape ambient_dim x kernel_dim. Uses QR decomposition to ensure orthonormal outputs.
        Returns:
            th.Tensor: A tensor of shape (ambient_dim, kernel_dim) representing the orthonormal basis.
        """
        super().__init__()
        assert kernel_dim==1, "Only one-dimensional kernel distribution tested."
        layers = []
        in_dim = ambient_dim*kernel_dim

        for h_dim in hidden_layer_dims:
            layers.append(th.nn.Linear(in_dim, h_dim))
            layers.append(th.nn.ReLU())
            in_dim = h_dim

        layers.append(th.nn.Linear(in_dim, ambient_dim * kernel_dim))

        self.net = th.nn.Sequential(*layers)
        self.ambient_dim, self.kernel_dim = ambient_dim, kernel_dim

    def forward(self, x):
        # x: [batch, kernel_dim*ambient_dim]
        flat = self.net(x)
        M    = flat.view(-1, self.ambient_dim, self.kernel_dim)
        M_norm = th.norm(M, dim=-2, keepdim=True)
        return M / M_norm
    

def get_non_default_args(parser, parsed_args) -> dict:
    """Returns all non-default arguments from the parsed args."""
    defaults = parser.parse_args([])
    return {
    k: v for k, v in vars(parsed_args).items()
    if getattr(parsed_args, k) != getattr(defaults, k)}