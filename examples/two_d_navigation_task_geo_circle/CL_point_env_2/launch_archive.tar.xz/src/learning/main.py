from typing import List
import os
import logging
import argparse

import gym
import torch

from src.learning.aa_policy_training.train_policies import train_and_save_pis_and_buffers
from src.learning.bb_symmetry.utils import compute_and_save_kernel
from src.learning.cc_hereditary_geometry.utils import learn_hereditary_symmetry

def run_hereditary_symmetry_discovery(tasks: List[gym.Env],
                                      save_dir_base: str,
                                      oracles: List[torch.nn.Module],
                                      parser: argparse.ArgumentParser):
    args=parser.parse_args()

    ##############################s########################################################################################################
    if args.train_policies:
        logging.info("Training policies and saving replay buffers for each task...")
        task_dirs=train_and_save_pis_and_buffers(tasks=tasks,
                                                save_dir=save_dir_base,
                                                args=args)
        logging.info("Finished training policies and saving replay buffers for each task.")
    else:
        logging.info("Skipping policy training, using pre-trained policies and replay buffers.")
        task_dirs=[f"{save_dir_base}/task_{i}" for i in range(args.n_tasks)]
        if not all(os.path.exists(dir) for dir in task_dirs):
            raise FileNotFoundError(f"Some task directories do not exist: {task_dirs}")
        
    ######################################################################################################################################

    kernel_frames = []
    if args.compute_kernel:
        
        logging.info("Computing saving pointwise kernel bases for each task...")
        for dir in task_dirs:
            kernel_frame = compute_and_save_kernel(dir=dir,
                                        args=args)
            kernel_frames.append(kernel_frame)
        logging.info("Finished saving pointwise kernel bases for each task.")
    else:

        from src.utils import FrameNet
        logging.info("Skipping kernel computation, using pre-computed kernel frame.")
        for dir in task_dirs:
            kernel_frame=FrameNet(ambient_dim=args.ambient_dim, kernel_dim=args.kernel_dim, hidden_layer_dims=args.hidden_layer_dims_neural_kernel)
            kernel_frame.load_state_dict(torch.load(f"{dir}/neural_kernel.pt"))
            kernel_frames.append(kernel_frame)

    ######################################################################################################################################

    if args.learn_hereditary_symmetry:
        logging.info("Starting hereditary geometry discovery...")
        learn_hereditary_symmetry(dirs=task_dirs,
                                parser=parser,
                                oracles=oracles,
                                tasks_frameestimators=kernel_frames)
        logging.info("Finished hereditary geometry discovery.")
    else:
        logging.info("Skipping hereditary geometry discovery, using pre-computed charts.")
        #TODO, here we need to load the pre-computed charts.
        # This is not implemented yet, but we assume that the charts are already computed and saved in the task directories.
        # For now, we just log this information.
        logging.info("Assuming pre-computed charts are available in the task directories.")