from typing import Literal, Optional
import logging
from sklearn.neighbors import KernelDensity
from tqdm import tqdm

import torch
import numpy as np

from src.utils import FrameNet
from src.learning.aa_policy_training.utils import load_replay_buffer
from src.learning.bb_symmetry.kernel_approx import KernelFrameEstimator


def compute_and_save_kernel(dir: str,
                                  args) -> FrameNet:
    """
    Learn a frame of a kernel distribution from a replay buffer by first learning pointwise kernel bases and then training a neural network to approximate the frame.

    Returns:
    neural_kernel: FrameNet
        A neural network that approximates the frame of the kernel distribution.
    """
    replay_buffer_name:str=dir+"/replay_buffer.pkl"
    n_steps=int(args.n_steps_train_pis/args.n_envs)
    replay_buffer = load_replay_buffer(replay_buffer_name, N_steps=n_steps)
    assert args.kernel_in in replay_buffer.keys(), f"Kernel input {args.kernel_in} not found in replay buffer keys: {replay_buffer.keys()}"
    assert args.kernel_out in replay_buffer.keys(), f"Kernel output {args.kernel_out} not found in replay buffer keys: {replay_buffer.keys()}"
    
    all_ps = replay_buffer[args.kernel_in]
    all_ns = replay_buffer[args.kernel_out]



    frame_estimator = KernelFrameEstimator(ps=all_ps, 
                                           kernel_dim=args.kernel_dim, 
                                           ns=all_ns, epsilon_ball=args.epsilon_ball, 
                                           epsilon_level_set=args.epsilon_level_set,
                                           n_neighbors_in_level_set=args.n_neighbors_in_level_set,)
    _pointwise_frame = frame_estimator.compute()


    # Convert to pytorch tensor, only keep those ps and ns where we can reliably compute a pointwise frame.
    pointwise_frame = torch.stack(list(_pointwise_frame.values()), dim=0)
    ps = all_ps[list(_pointwise_frame.keys())]
    ns = all_ns[list(_pointwise_frame.keys())]
    del _pointwise_frame

    neural_kernel, _losses = train_neural_kernel(epochs=args.n_epochs_neural_kernel,
                        ps=ps,
                        kernel_bases=pointwise_frame,
                        hidden_layer_dims=args.hidden_layer_dims_neural_kernel,
                        batch_size=args.batch_size_neural_kernel,
                        sample_data_how=args.sample_data_how,
                        temperature=args.temperature,
                        )
    
    torch.save(pointwise_frame, dir+"/pointwise_frame.pt")
    torch.save(ps, dir+"/ps.pt")
    torch.save(ns, dir+"/ns.pt")
    torch.save(all_ps, dir+"/all_ps.pt")
    torch.save(all_ns, dir+"/all_ns.pt")
    torch.save(neural_kernel.state_dict(), dir+"/neural_kernel.pt")

    return neural_kernel
    

def train_neural_kernel(ps: torch.Tensor,
                        kernel_bases: torch.Tensor,
                        hidden_layer_dims: list[int],
                        
                        sample_data_how: Literal["uniform_replay", "uniform_manifold"],
                        temperature: Optional[float]=None,

                        epochs: int=10_000,
                        batch_size: int = 64,
                        ):
    
    
    """
    Learn a frame from kernel bases using a dense neural network.
    
    Args:
    ps: torch.Tensor of shape (n_samples, ambient_dim)
    kernel_bases: torch.Tensor of shape (n_bases, ambient_dim, kernel_dim)
    hidden_layer_dims: list of integers specifying torche hidden layer dimensions
    """
    assert sample_data_how in ["uniform_replay", "uniform_manifold"], "Unsupported sampling mode. Choose 'uniform_replay' or 'uniform_manifold'."
    if sample_data_how == "uniform_manifold":
        assert temperature is not None, "Temperature must be provided for uniform manifold sampling."

    n_samples, ambient_dim, kernel_dim = kernel_bases.shape
    net = FrameNet(ambient_dim, kernel_dim, hidden_layer_dims)
    optimizer = torch.optim.Adam(net.parameters(), lr=0.00015)
    losses = []

    with torch.no_grad():
        ps_test = ps[:100]
        kernel_bases_test = kernel_bases[:100]
        frame_hat_test = net(ps_test)
        assert frame_hat_test.shape == kernel_bases_test.shape, "Frame hat shape does not match kernel bases shape. Expected {}, got {}".format(kernel_bases_test.shape, frame_hat_test.shape)

    progress_bar = tqdm(range(epochs), desc=f"Training neural kernel w/ sampling {sample_data_how} and β={temperature}.", unit="epoch")


    if sample_data_how == "uniform_manifold":
        """Give higher sampling probability to less frequent samples to estimate kernel more evenly."""
        logging.info("Initializing uniform manifold sampling")
        # kde = scipy.stats.gaussian_kde(ps.T)
        # densities = kde(ps.T)
        # probs = torch.exp(-temperature*torch.tensor(densities))
        # ws_ps = probs / probs.sum()
        # del kde, densities, probs
        n, d = ps.shape
        h = n ** (-1 / (d + 4))
        ps_np = ps.cpu().numpy()
        kde = KernelDensity(bandwidth=h, kernel='gaussian')
        kde.fit(ps_np)

        log_dens = kde.score_samples(ps_np)
        probs = torch.exp(-temperature * torch.tensor(np.exp(log_dens)))
        ws_ps = torch.tensor(probs / probs.sum())
        logging.info("Initialized uniform manifold sampling")
    else:
        ws_ps = torch.ones(n_samples) / n_samples

    for epoch in progress_bar:
        
        # Sample data.
        idxs = torch.multinomial(ws_ps, num_samples=batch_size, replacement=False)
        ps_batch= ps[idxs]
        bases_batch= kernel_bases[idxs]

        optimizer.zero_grad()
        frame_hat = net(ps_batch)
        loss = torch.mean(torch.sum(torch.mean((frame_hat - bases_batch) ** 2, -2), dim=-1), -1)
        loss.backward()
        optimizer.step()

        losses.append(loss.item())
        if epoch % 500 == 0:
            progress_bar.set_postfix(loss=loss.item())
    
    return net, losses